<?php

namespace App\Http\Controllers;

use App\Models\AboutsUs;
use App\Models\Cart as ModelsCart;
use App\Models\Category;
use App\Models\MyShop;
use App\Models\Order;
use App\Models\Property;
use App\Models\User;
use App\Notifications\OrderPlaced;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Notification;

class FrontController extends Controller
{
    public function search(Request $request)
    {
        $term = $request->searching;
        $country = $request->country;
        $state = $request->state;
        $city = $request->city;

        $products = Property::with('onSaleAttributes')
            ->has('onSaleAttributes')
            ->where(function ($qry) use ($term) {
                $qry->where('name', 'like', '%' . $term . '%')
                    ->orWhere('slug', 'like', '%' . $term . '%')
                    ->orWhere('short_description', 'like', '%' . $term . '%')
                    ->orWhere('description', 'like', '%' . $term . '%')
                    ->orWhere('keywords', 'like', '%' . $term . '%')
                    ->orWhere('warrenty', 'like', '%' . $term . '%')
                    ->orWhereHas('category', function ($query) use ($term) {
                        $query->where('name', 'like', '%' . $term . '%')
                            ->where('status', 1)
                            ->orWhere('slug', 'like', '%' . $term . '%');
                    })


                 ;
            })
            ->when($country, function ($query) use ($country) {
                $query->where('country_id', $country);
            })
            ->when($state, function ($query) use ($state) {
                $query->where('state_id', $state);
            })

            ->when($city, function ($query) use ($city) {
                $query->where('city_id', $city);
            })

            ->get();

        return view('search', ['products' => $products, 'term' => $term]);
    }

    public function shop()
    {
        $categories = Category::withCount('products')
            // ->with('photo')
            ->has('products')
            ->where('status', 1)
            ->where('in_home_page', 1)
            // ->whereHas('photo')
            ->orderBy('products_count', 'desc')
            ->get();
            // return $categories;

        return view('shop', ['categories' => $categories]);
    }

    public function profile()
    {
        return view('profile');
    }

    public function checkout()
    {
        $cartCount = ModelsCart::where('user_id', userId())->count();
        return view('checkout', ['cartCount' => $cartCount]);
    }

    public function aboutUs()
    {
        $aboutUs = AboutsUs::first();

        return view('about-us', ['aboutUs' => $aboutUs]);
    }



    public function categoryAbout($category){
        $category =  Category::where('slug', $category)->first();

        return view('category-write-up', compact(['category']));

    }
    public function contactUs()
    {
        $myShop = MyShop::first();

        return view('contact-us', ['myShop' => $myShop]);
    }

    public function verify($code)
    {
        $user = User::where('verification_code', $code)->firstOrFail();

        $user->email_verified_at = date('Y-m-d h:m:s');

        $user->save();

        $orders = Order::where("user_id", $user->id)
            ->where("order_status", "waiting")
            ->get(["id"]);

        foreach ($orders as $order) {
            $order->update(["order_status" => "pending"]);

            $data = ["name" => auth()->user()->name, "link" => route("order.detail", $order->id)];
            Notification::send(auth()->user(), new OrderPlaced($data));
        }

        return view('verify', ["order" => $orders->count()]);
    }

    public function order()
    {
        return view('order');
    }

    public function orderDetail($id)
    {
        $order = Order::where('id', $id)->with('orderDetail')->first();
        // return $order;

        return view('order-detail', ['order' => $order]);
    }
}
