<div class="offset-md-3 p-4 col-md-6 col-sm-12 bg-white rounded-5 shadow-5-strong">
    <div class="p-4 text-center text-uppercase text-danger">
        <i style="font-size: 110px;" class="fa {{ $icon ?? 'fa-exclamation-triangle' }}" aria-hidden="true"></i>
        <h3 class="small-font f-500 p-4">
            {{ $title ?? 'Empty' }}
        </h3>
    </div>
</div>
