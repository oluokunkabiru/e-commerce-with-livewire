<div wire:loading.delay.class='show' class="component-progress-spin w-100 d-flex justify-content-center z-11">
    <div class="spinner-border text__primary" role="status">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
