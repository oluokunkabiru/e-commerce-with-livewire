@for ($i = 0; $i < $star; $i++)
    <i class="fas fa-star text__primary smaller-font"></i>
@endfor
@for ($j = $i; $j < 5; $j++)
    <i class="far fa-star text__primary smaller-font"></i>
@endfor
