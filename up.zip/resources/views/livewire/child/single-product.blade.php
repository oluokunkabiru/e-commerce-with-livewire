@push('extra-css')
<style>
    #social-links li {
            display: inline-block;
            padding: 5px;
            text-align: center;
            list-style: none;
        }
</style>

@endpush


<div  wire:ignore.self class="product-card p-relative text-center w-100 bg-white rounded-3 shadow-1-strong">
    <div wire:loading class="single-product-progress-spin w-100 d-flex justify-content-center z-11">
        <div class="spinner-border text__primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    @if (session()->has('product_success_msg'))
        <div class="message bg-secondary text-light p-2 text-uppercase f-500 smaller-font">
            {{ session('product_success_msg') }}
        </div>
    @endif
    @if (session()->has('product_error_msg'))
        <div class="message bg-danger text-light p-2 text-uppercase f-500 smaller-font">
            {{ session('product_error_msg') }}
        </div>
    @endif
    <button wire:click='addToCart' class="btn-product btn-cart btn btn-light btn-lg btn-floating">
        <i class="fa fa-phone" aria-hidden="true"></i></button>

    <button wire:click="addTowishlist" class="btn-product btn-whislist btn btn-light btn-lg btn-floating">
        <i class="fa fa-heart" aria-hidden="true"></i></button>

    <a class="btn mb-2 btn-light p-0 shadow-0"
        href="{{ route('property.detail', [$product->slug, 'attribute=' . $product->onSaleAttributes->first()->id]) }}">
        <img  style="width:100%; height:150px; object-fit:cover" src="{{ $product->onSaleAttributes->first()->getMedia('products')->first() !=null?$product->onSaleAttributes->first()->getMedia('products')->first()->getFullUrl():null }}"
            class="img-fluid my-4" alt="">
        <div wire:loading  style="height: 255px;" class="img-progress">
            <div class="spinner-border text__primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </a>
    <h1 class="small-font">{{ $product->name }}   </h1>

    {{-- <div class="d-flex stars mb-2 justify-content-center">
        @include('partial.star',['star' => $rate])
    </div> --}}

    <div class="h-25px d-flex justify-content-center">
        <p class="text-line-through smaller-font f-500 mr-3 text-gray"> {{ Country()->currency_symbol }} {{ number_format(($product->onSaleAttributes->first()->mrp), 2) }}
        </p>
        <p class="smaller-font text-black f-600">{{ Country()->currency_symbol }} {{ number_format((($product->onSaleAttributes->first()->price)+(0.01*settings()->agent_fee*$product->onSaleAttributes->first()->price)), 2) }} </p>
    </div>
    <p class="smaller-font pb-3 {{ $moreAttr > 0 ? 'text-black' : 'invisible' }}">{{ $moreAttr }} more
     attribute{{ $moreAttr > 1 ? 's' : '' }}</p>


     <div class="my-1">
        
        {!! \Share::page(
            route('property.detail', array_filter([$product->slug, 'attribute=' . $product->onSaleAttributes->first()->id, (auth()->user() ? 'referral_code='.auth()->user()->referral_code:null)])),
            $product->name
        )
            ->facebook()
            ->twitter()
            ->linkedin()
            ->telegram()
            ->whatsapp()
            ->reddit()
             !!}

     </div>
</div>
