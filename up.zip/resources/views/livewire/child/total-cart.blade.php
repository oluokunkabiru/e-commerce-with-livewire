<a href="{{ route('cart') }}" class="btn btn-white btn-floating"><i class="fas fa-phone"></i>
    <span class="cart-badge badge rounded-pill badge-notification bg__primary"
        style="right: -2px;">{{ totalCart() }}</span>
</a>
